Hello and thank's for checking out the press kit for debris.

In this folder you will find various single images, for you to use in any combination.

Folders:
* 'Youtube Thumbnail': all layers
  - ordered from back to front in a format
  - suitable for use as a YouTube thumbnail (and other previews in 16:9 aspect ratio)

If you need anything you can always reach out to me via service@evar.space!